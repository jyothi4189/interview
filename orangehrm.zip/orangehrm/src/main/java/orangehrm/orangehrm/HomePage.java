package orangehrm.orangehrm;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends BasePage{

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@class='oxd-table-body']/descendant::div[contains(@class,'oxd-table-row')]")
	private List<WebElement> noOfEmployeerows;
	
@FindBy(xpath="//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']/span")
private WebElement RecordsFound;
public int getNoOfEmployeeCount() {
	return noOfEmployeerows.size();
}
public int getrecordCount() {
	String data=RecordsFound.getText();
	int startindex=data.indexOf("(")+1;
	int endindex=data.indexOf(")");
	String data1=data.substring(startindex, endindex);

	return Integer.parseInt(data1);
}
public void ClickOnMenu(String menu) throws InterruptedException {
	List<WebElement> allitems = driver.findElements(By.className("oxd-main-menu-item"));
for(WebElement item:allitems) {
	String menuitem = item.findElement(By.tagName("span")).getText();
	if(menuitem.equalsIgnoreCase(menu)) {
		item.click();
		break;
	}
	Thread.sleep(2000);
}
}
public void addUser() {
	driver.findElement(By.cssSelector(".orangehrm-header-container button"));

}
}
