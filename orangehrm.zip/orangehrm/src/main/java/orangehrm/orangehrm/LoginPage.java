package orangehrm.orangehrm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage{

	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	@FindBy(name="username")
	private WebElement UserNametbx;
	@FindBy(name="password")
	private WebElement PassWordtbx;
	@FindBy(css="[type='submit']")
	private WebElement loginbtn;
	public void testLogin(String un,String pwd) {
		UserNametbx.sendKeys(un);
		PassWordtbx.sendKeys(pwd);
		loginbtn.click();
	}

}
