package orangehrm.orangehrm;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestScriptOrangeHrm extends BaseTestOrangeHrm{
@Test(dataProvider="LoginData",enabled=false)
public void testLogin(String un,String pwd) {
	LoginPage loginpage=new LoginPage(driver);
	loginpage.testLogin(un, pwd);
}
@Test
public void testSearch() throws InterruptedException {
	LoginPage loginpage=new LoginPage(driver);
	loginpage.testLogin("Admin", "admin123");
	HomePage homepage=new HomePage(driver);
	homepage.ClickOnMenu("Admin");
	int employeeCount=homepage.getNoOfEmployeeCount();
	int recordsFound=homepage.getrecordCount();
	System.out.println(recordsFound);
	Assert.assertEquals(employeeCount, recordsFound);
}
@Test

public void addUser() throws InterruptedException {
	LoginPage loginpage=new LoginPage(driver);
	loginpage.testLogin("Admin", "admin123");
	HomePage homepage=new HomePage(driver);
	homepage.ClickOnMenu("Admin");
	
}
}
