package orangehrm.orangehrm;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class BaseTestOrangeHrm {
public WebDriver driver;
@BeforeMethod
public void initializeDriver() throws Exception {
	FileInputStream fis=new FileInputStream("C:\\Users\\jinka\\eclipse-workspace\\orangehrm\\data.property");
	Properties p=new Properties();
	p.load(fis);
String url=p.getProperty("url");
String Browser=p.getProperty("Browser");
if(Browser.equalsIgnoreCase("chrome")) {
	driver=new ChromeDriver();
}
else if(Browser.equalsIgnoreCase("firefox")) {
	driver=new FirefoxDriver();
}
else if(Browser.equalsIgnoreCase("edge")) {
	driver=new EdgeDriver();
}
driver.get(url);
driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
driver.manage().window().maximize();
}
@DataProvider(name="LoginData")
public Object[][] getLoginDetails() throws EncryptedDocumentException, IOException
{
	FileInputStream fis=new FileInputStream("C:\\Users\\jinka\\eclipse-workspace\\orangehrm\\logindata.xlsx");
	Workbook wb=WorkbookFactory.create(fis);
	Sheet sheet = wb.getSheet("login");
	int rowCount=sheet.getLastRowNum();
	int cellCount=sheet.getRow(0).getLastCellNum();
	Object[][] data=new Object[rowCount][cellCount];
	DataFormatter df=new DataFormatter();
	for(int i=0;i<rowCount;i++) {
		Row row = sheet.getRow(i+1);
		for(int j=0;j<cellCount;j++) {
			Cell cell=row.getCell(j);
			data[i][j]=df.formatCellValue(cell);
			
		}
	}
	return data;
	
}
	
	@AfterMethod(enabled=false)
public void tearDown() {
	if(driver!=null) {
		driver.quit();
	}
}
}
